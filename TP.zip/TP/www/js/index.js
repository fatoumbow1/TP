window.onload = function () {

    addButton.onclick = function () {
        let newTask = document.createElement('li');
        newTask.innerText = task.value;
        newTask.onclick = function () {
            alert(this.innerText);
        }
        $(newTask).on('swiperight', gererSwipeRight);
        $(newTask).on('swipeleft', gererSwipeLeft);

        taskList.appendChild(newTask);

        
        task.select();
        task.focus();
        $(taskList).listview('refresh');

    };

    resetButton.onclick = function () {
       taskList.innerHTML = '';

    }
}

function gererSwipeRight(){
         $(this).toggleClass('done');
}
function gererSwipeLeft(){
         $(this).remove();
}